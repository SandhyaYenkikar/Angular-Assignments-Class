import { Component } from '@angular/core';

@Component({
  selector: 'app-stock-price-update',
  imports: [],
  templateUrl: './stock-price-update.component.html',
  styleUrl: './stock-price-update.component.css'
})
export class StockPriceUpdateComponent {

}
