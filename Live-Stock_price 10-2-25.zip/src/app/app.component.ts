import { Component, OnDestroy } from '@angular/core';

import { interval, Subscription, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnDestroy {
  latestPrice: number | null = null;
  subscription: Subscription | undefined;
  stockPriceSUbject = new Subject<number>();

  constructor() {
    interval(2000)
      .pipe(map(() => (Math.random() * 1000).toFixed(2)))
      .subscribe(price => {
        console.log('New Stock Price', price);
        this.stockPriceSUbject.next(parseFloat(price));
      });
  }

  subscribeToStockUpdates() {
    this.subscription = this.stockPriceSUbject.subscribe(price => {
      this.latestPrice = price;
      console.log('Received stock price:', price);
    });
  }

  unsubscribeFromUpdates() {
    this.subscription?.unsubscribe();
    console.log('Unsubscribed from stock updates');
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}