import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartSubject = new BehaviorSubject<any[]>([]);
  cart$ = this.cartSubject.asObservable();

  addProduct(product: any) {
    const currentItems = this.cartSubject.value;
    this.cartSubject.next([...currentItems, product]);
  }

  removeProduct(productId: number) {
    const updatedItems = this.cartSubject.value.filter(item => item.id !== productId);
    this.cartSubject.next(updatedItems);
  }

  clearCart() {
    this.cartSubject.next([]);
  }
}
