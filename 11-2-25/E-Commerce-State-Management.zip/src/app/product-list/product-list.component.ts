import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-product-list',
  standalone: false,
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})

  export class ProductListComponent implements OnInit {
    products = [
      { id: 1, name: 'Product 1' },
      { id: 2, name: 'Product 2' },
      { id: 3, name: 'Product 3' },
      { id: 4, name: 'Product 4' },
      { id: 5, name: 'Product 5' }
    ];
  
    constructor(private cartService: CartService) {}
  
    ngOnInit(): void {}
  
    addToCart(product: any) {
      this.cartService.addProduct(product);
    }
  }


