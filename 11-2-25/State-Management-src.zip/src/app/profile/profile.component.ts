import { Component } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-profile',
  standalone: false,
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css',
})
export class ProfileComponent {
  user: string | null = null;
  isLoggedIn: string | null = null;
  constructor(private auth: AuthService) {
    this.auth.dashboard.subscribe((username) => (this.user = username));
    this.auth.isLoggedIn$.subscribe(
      (isLoggedIn) => (this.isLoggedIn = isLoggedIn)
    );
  }
}
