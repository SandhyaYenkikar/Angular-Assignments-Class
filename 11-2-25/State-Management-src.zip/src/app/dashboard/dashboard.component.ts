import { Component } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent {
  user: string | null = null;
  isLoggedIn: string | null = null;
  constructor(private auth: AuthService) {
    this.auth.dashboard.subscribe((username) => (this.user = username));
    this.auth.isLoggedIn$.subscribe(
      (isLoggedIn) => (this.isLoggedIn = isLoggedIn)
    );
  }
}
