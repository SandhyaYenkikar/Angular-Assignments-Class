import { Injectable, ViewContainerRef } from '@angular/core';
import { DynamicComponent } from './dynamic/dynamic.component';

@Injectable({
  providedIn: 'root'
})
export class DynamicComponentService {
  constructor() { }

  loadComponent(container: ViewContainerRef) {
    container.clear();
    container.createComponent(DynamicComponent);
  }
}
