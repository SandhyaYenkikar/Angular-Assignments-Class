import { Component, ViewChild } from '@angular/core';
import { DynamicComponentDirective } from './dynamic-comp.directive';
import { DynamicComponentService } from './dynamic-component.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false
})
export class AppComponent {
clear() {
throw new Error('Method not implemented.');
}
  @ViewChild(DynamicComponentDirective, { static: true }) dynamicComponent!: DynamicComponentDirective;

  constructor(private dynamicComponentService: DynamicComponentService) { }

  loadDynamicComponent() {
    this.dynamicComponentService.loadComponent(this.dynamicComponent.viewContainerRef);
  }
}
