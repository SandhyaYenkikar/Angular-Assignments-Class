import { AfterViewInit, Component } from '@angular/core';
import { debounceTime, distinctUntilChanged, fromEvent, map } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent implements AfterViewInit {

  //title = 'debouncing';
  ngAfterViewInit(): void {
    const searchInput = document.getElementById('search');
    if (searchInput){
      fromEvent(searchInput, 'input')
      .pipe(
        map((event: any) => event.target.value),
        debounceTime(5000),
        distinctUntilChanged()
      )
      .subscribe(value => console.log('Searching for', value));
    }else{
      console.error('Search input not found in the DOM');
    }
  }
}
