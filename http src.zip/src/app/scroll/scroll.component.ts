import { Component } from '@angular/core';
import { fromEvent } from 'rxjs';
import { throttleTime } from 'rxjs/operators';

@Component({
  selector: 'app-scroll',
  template: `<p>Scroll to see the effect in console</p>`,
  styleUrls: ['./scroll.component.css'],
  standalone:false
})
export class ScrollComponent {
  constructor() {
    fromEvent(window, 'scroll')
      .pipe(throttleTime(2000))
      .subscribe(() => console.log('user is scrolling'));
  }
}
