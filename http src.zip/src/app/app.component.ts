import { AfterViewInit, Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { fromEvent, of } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { ScrollComponent } from "./scroll/scroll.component";

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  //imports: [ScrollComponent]
})
export class AppComponent implements AfterViewInit {
  title = 'http';

  constructor(private http: HttpClient) {}

  ngAfterViewInit() {
    const searchInput = document.getElementById('search');
    if (searchInput) {
      fromEvent(searchInput, 'input')
        .pipe(
          map((event: any) => event.target.value.trim()),
          debounceTime(500),
          distinctUntilChanged(),
          switchMap((value) => {
            if (!value) {
              console.log("Empty input, skipping request");
              return of([]);
            }
            const apiurl = `dummyapiurllink=${value}`;
            console.log('API Request', apiurl);
            return this.http.get(apiurl).pipe(
              map((response: any) => {
                console.log('API responses', response);
                return response.products || [];
              }),
              catchError(error => {
                console.error('API Error:', error);
                return of([]);
              })
            );
          })
        )
    }
  }
}
